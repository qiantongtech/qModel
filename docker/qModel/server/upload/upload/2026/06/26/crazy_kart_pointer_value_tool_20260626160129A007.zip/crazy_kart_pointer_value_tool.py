# -*- coding: utf-8 -*-
"""
疯狂赛车 — 多级指针 4 字节读写

- 进程固定 CrazyKart.exe；配置：基地址 RVA、中间偏移、最后一级偏移。
- 「一键影藏」：六项装饰写 0；车手支持读取与手动写入。

配置：与 exe 或脚本同目录的 crazy_kart_pointer_value_config.json
"""

from __future__ import annotations

import ctypes
import json
import re
import string
import struct
import sys
from ctypes import wintypes
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Optional, Sequence, Union

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except ImportError as e:
    raise SystemExit("需要 tkinter（Windows 完整版 Python 自带）") from e

PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_OPERATION = 0x0008
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_ALL_MEM_ACCESS = (
    PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_QUERY_INFORMATION
)

TH32CS_SNAPPROCESS = 0x00000002
TH32CS_SNAPMODULE = 0x00000008
TH32CS_SNAPMODULE32 = 0x00000010

INVALID_HANDLE_VALUE = wintypes.HANDLE(-1).value

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)
shell32.IsUserAnAdmin.restype = wintypes.BOOL


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260),
    ]


class MODULEENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("th32ModuleID", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("GlblcntUsage", wintypes.DWORD),
        ("ProccntUsage", wintypes.DWORD),
        ("modBaseAddr", ctypes.c_void_p),
        ("modBaseSize", wintypes.DWORD),
        ("hModule", ctypes.c_void_p),
        ("szModule", wintypes.WCHAR * 256),
        ("szExePath", wintypes.WCHAR * 260),
    ]


def _check_bool(result, func, args):
    if not result:
        raise ctypes.WinError(ctypes.get_last_error())
    return args


kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.CloseHandle.restype = wintypes.BOOL
kernel32.ReadProcessMemory.argtypes = [
    wintypes.HANDLE,
    wintypes.LPCVOID,
    wintypes.LPVOID,
    ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t),
]
kernel32.ReadProcessMemory.restype = wintypes.BOOL
kernel32.ReadProcessMemory.errcheck = _check_bool
kernel32.WriteProcessMemory.argtypes = [
    wintypes.HANDLE,
    wintypes.LPVOID,
    wintypes.LPCVOID,
    ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t),
]
kernel32.WriteProcessMemory.restype = wintypes.BOOL
kernel32.WriteProcessMemory.errcheck = _check_bool
kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
kernel32.Process32FirstW.restype = wintypes.BOOL
kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
kernel32.Process32NextW.restype = wintypes.BOOL
kernel32.Module32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MODULEENTRY32W)]
kernel32.Module32FirstW.restype = wintypes.BOOL
kernel32.Module32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(MODULEENTRY32W)]
kernel32.Module32NextW.restype = wintypes.BOOL


def is_admin() -> bool:
    try:
        return bool(shell32.IsUserAnAdmin())
    except Exception:
        return False


def ensure_admin() -> None:
    if is_admin():
        return
    SW_SHOWNORMAL = 1
    exe = sys.executable
    params = " ".join(f'"{arg}"' if " " in arg else arg for arg in sys.argv)
    rc = ctypes.windll.shell32.ShellExecuteW(
        None, "runas", exe, params, None, SW_SHOWNORMAL
    )
    if rc <= 32:
        raise OSError(f"UAC 提权启动失败，返回值: {rc}")
    sys.exit(0)


def get_pid_by_name(process_name: str) -> Optional[int]:
    name_lower = process_name.lower()
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap == INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        pe = PROCESSENTRY32W()
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        if not kernel32.Process32FirstW(snap, ctypes.byref(pe)):
            raise ctypes.WinError(ctypes.get_last_error())
        while True:
            exe = pe.szExeFile
            if exe.lower().endswith(name_lower) or exe.lower() == name_lower:
                return int(pe.th32ProcessID)
            if not kernel32.Process32NextW(snap, ctypes.byref(pe)):
                break
        return None
    finally:
        kernel32.CloseHandle(snap)


def open_process(pid: int) -> wintypes.HANDLE:
    h = kernel32.OpenProcess(PROCESS_ALL_MEM_ACCESS, False, pid)
    if not h:
        raise ctypes.WinError(ctypes.get_last_error())
    return h


def get_module_base(pid: int, module_name: str) -> Optional[int]:
    snap_flags = TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32
    snap = kernel32.CreateToolhelp32Snapshot(snap_flags, pid)
    if snap == INVALID_HANDLE_VALUE:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        me = MODULEENTRY32W()
        me.dwSize = ctypes.sizeof(MODULEENTRY32W)
        if not kernel32.Module32FirstW(snap, ctypes.byref(me)):
            raise ctypes.WinError(ctypes.get_last_error())
        target = module_name.lower()
        while True:
            if me.szModule.lower() == target:
                base = int(ctypes.cast(me.modBaseAddr, ctypes.c_void_p).value or 0)
                return base if base else None
            if not kernel32.Module32NextW(snap, ctypes.byref(me)):
                break
        return None
    finally:
        kernel32.CloseHandle(snap)


def read_process_memory(h_process: wintypes.HANDLE, address: int, size: int) -> bytes:
    buf = ctypes.create_string_buffer(size)
    read_count = ctypes.c_size_t(0)
    kernel32.ReadProcessMemory(
        h_process,
        ctypes.c_void_p(address),
        buf,
        size,
        ctypes.byref(read_count),
    )
    return buf.raw[: read_count.value]


def write_process_memory(h_process: wintypes.HANDLE, address: int, data: bytes) -> int:
    written = ctypes.c_size_t(0)
    kernel32.WriteProcessMemory(
        h_process,
        ctypes.c_void_p(address),
        data,
        len(data),
        ctypes.byref(written),
    )
    return int(written.value)


def read_pointer_value(h_process: wintypes.HANDLE, address: int, is_64bit: bool) -> int:
    size = 8 if is_64bit else 4
    raw = read_process_memory(h_process, address, size)
    if len(raw) < size:
        raise ValueError(f"读取指针不完整 @ 0x{address:X}")
    return struct.unpack("<Q" if is_64bit else "<I", raw)[0]


def resolve_pointer_chain(
    h_process: wintypes.HANDLE,
    base_address: int,
    offsets: Sequence[int],
    *,
    is_64bit: bool = False,
) -> int:
    if not offsets:
        raise ValueError("偏移链不能为空")
    addr = base_address + offsets[0]
    for i in range(1, len(offsets)):
        addr = read_pointer_value(h_process, addr, is_64bit) + offsets[i]
    return addr


def parse_int_value(value: Union[int, str, float]) -> int:
    if isinstance(value, bool):
        raise TypeError("布尔值无效")
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    s = str(value).strip()
    if s.lower().startswith("0x"):
        return int(s, 16)
    if s and all(c in string.hexdigits for c in s):
        return int(s, 16)
    return int(s, 10)


def parse_write_decimal_u32(text: str) -> int:
    s = str(text).strip()
    if not s:
        raise ValueError("数值为空")
    if not s.lstrip("-").isdigit():
        raise ValueError("请只填写十进制数字（0-9）")
    return int(s, 10) & 0xFFFFFFFF


def parse_mid_offset_list(text: str) -> List[int]:
    parts = [p.strip() for p in text.replace(";", ",").split(",") if p.strip()]
    if not parts:
        raise ValueError("中间偏移不能为空")
    return [parse_int_value(p) for p in parts]


def parse_ce_offset_expr(text: str) -> int:
    s = "".join((text or "").strip().split())
    if not s:
        raise ValueError("偏移表达式为空")
    m = re.fullmatch(r"(?i)([0-9A-F]+)([+-])([0-9A-F]+)", s)
    if m:
        a = parse_int_value(m.group(1))
        op = m.group(2)
        b = parse_int_value(m.group(3))
        return a + b if op == "+" else a - b
    return parse_int_value(s)


DEFAULT_PROCESS_NAME = "CrazyKart.exe"

HIDE_WRITE_DELTAS: Sequence[int] = (0x78, 0x84, 0x70, 0x88, 0x74, 0x80)
DRIVER_DELTA = -0x1A8


def config_file_path() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "crazy_kart_pointer_value_config.json"
    return Path(__file__).resolve().parent / "crazy_kart_pointer_value_config.json"


@dataclass
class ToolConfig:
    process_name: str = DEFAULT_PROCESS_NAME
    module_name: str = DEFAULT_PROCESS_NAME
    is_64bit: bool = False
    static_offset: str = "622060"
    pointer_mid_offsets: str = "190"
    car_last_offset: str = "2DB8"

    def validate(self) -> None:
        parse_int_value(self.static_offset or "0")
        parse_mid_offset_list(self.pointer_mid_offsets)
        parse_ce_offset_expr(self.car_last_offset or "")


def build_pointer_chain(cfg: ToolConfig) -> List[int]:
    mids = parse_mid_offset_list(cfg.pointer_mid_offsets)
    last = parse_ce_offset_expr(cfg.car_last_offset or "")
    base_rva = parse_int_value(cfg.static_offset)
    return [base_rva] + mids + [last]


def load_config() -> ToolConfig:
    p = config_file_path()
    if not p.is_file():
        return ToolConfig()
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
        cfg = ToolConfig()
        for k, v in raw.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        cfg.process_name = DEFAULT_PROCESS_NAME
        cfg.module_name = DEFAULT_PROCESS_NAME
        return cfg
    except Exception:
        return ToolConfig()


def save_config(cfg: ToolConfig) -> None:
    p = config_file_path()
    p.write_text(
        json.dumps(asdict(cfg), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def popup_ok() -> None:
    messagebox.showinfo("", "成功")


def popup_fail() -> None:
    messagebox.showerror("", "失败")


class PointerValueApp:
    def __init__(self) -> None:
        self.cfg = load_config()
        self.root = tk.Tk()
        self.root.title("疯狂赛车 · 指针读写")
        self.root.resizable(False, False)

        self._status = tk.StringVar(value="就绪")
        self._driver_read = tk.StringVar(value="—")
        self._driver_write = tk.StringVar()

        self._v_static = tk.StringVar(value=self.cfg.static_offset)
        self._v_mid_offsets = tk.StringVar(value=self.cfg.pointer_mid_offsets)
        self._v_car_last = tk.StringVar(value=self.cfg.car_last_offset)

        pad = {"padx": 6, "pady": 3}
        main = ttk.Frame(self.root, padding=8)
        main.pack(fill=tk.BOTH)

        cfg = ttk.LabelFrame(main, text="地址配置", padding=6)
        cfg.pack(fill=tk.X, pady=(0, 6))
        cfg.columnconfigure(1, weight=1)
        cfg.columnconfigure(3, weight=1)

        ttk.Label(cfg, text="基地址 RVA").grid(row=0, column=0, sticky=tk.W, **pad)
        ttk.Entry(cfg, textvariable=self._v_static, width=12).grid(row=0, column=1, sticky=tk.W, **pad)
        ttk.Label(cfg, text="中间偏移").grid(row=0, column=2, sticky=tk.W, **pad)
        ttk.Entry(cfg, textvariable=self._v_mid_offsets, width=12).grid(row=0, column=3, sticky=tk.W, **pad)
        ttk.Label(cfg, text="最后一级").grid(row=1, column=0, sticky=tk.W, **pad)
        ttk.Entry(cfg, textvariable=self._v_car_last, width=12).grid(row=1, column=1, sticky=tk.W, **pad)
        ttk.Button(cfg, text="保存配置", command=self.on_save_config).grid(
            row=1, column=3, sticky=tk.E, **pad
        )

        act = ttk.LabelFrame(main, text="操作", padding=6)
        act.pack(fill=tk.X)

        ttk.Button(act, text="一键影藏", command=self.on_one_click_hide).pack(fill=tk.X, ipady=4, pady=(0, 6))

        drv = ttk.Frame(act)
        drv.pack(fill=tk.X)
        ttk.Label(drv, text="车手").grid(row=0, column=0, padx=(0, 4))
        ttk.Label(drv, text="当前").grid(row=0, column=1, padx=(0, 2))
        ttk.Entry(drv, textvariable=self._driver_read, state="readonly", width=10).grid(
            row=0, column=2, padx=(0, 8)
        )
        ttk.Label(drv, text="写入").grid(row=0, column=3, padx=(0, 2))
        ttk.Entry(drv, textvariable=self._driver_write, width=10).grid(row=0, column=4, padx=(0, 8))
        ttk.Button(drv, text="读取", command=self.on_refresh_driver, width=5).grid(row=0, column=5, padx=2)
        ttk.Button(drv, text="写入", command=self.on_write_driver, width=5).grid(row=0, column=6, padx=2)

        ttk.Label(self.root, textvariable=self._status, relief=tk.SUNKEN, anchor=tk.W).pack(
            fill=tk.X, side=tk.BOTTOM
        )

    def _gather_config_from_ui(self) -> ToolConfig:
        return ToolConfig(
            process_name=DEFAULT_PROCESS_NAME,
            module_name=DEFAULT_PROCESS_NAME,
            is_64bit=self.cfg.is_64bit,
            static_offset=self._v_static.get().strip() or "0",
            pointer_mid_offsets=self._v_mid_offsets.get().strip() or "190",
            car_last_offset=self._v_car_last.get().strip() or "2DB8",
        )

    def _open_session_and_resolve_car_addr(
        self, c: ToolConfig
    ) -> tuple[wintypes.HANDLE, int]:
        pid = get_pid_by_name(c.process_name)
        if pid is None:
            raise RuntimeError("未找到进程")
        mod = get_module_base(pid, c.module_name)
        if mod is None:
            raise RuntimeError("未找到模块")
        h = open_process(pid)
        chain = build_pointer_chain(c)
        car_addr = resolve_pointer_chain(h, mod, chain, is_64bit=c.is_64bit)
        return h, car_addr

    def _write_u32_at_delta(
        self, car_addr: int, delta: int, value: int, h: wintypes.HANDLE
    ) -> None:
        final = car_addr + delta
        n = write_process_memory(h, final, struct.pack("<I", value & 0xFFFFFFFF))
        if n != 4:
            raise RuntimeError("写入失败")

    def on_save_config(self) -> None:
        try:
            c = self._gather_config_from_ui()
            c.validate()
            self.cfg = c
            save_config(self.cfg)
            self._status.set("配置已保存")
            popup_ok()
        except Exception:
            self._status.set("保存失败")
            popup_fail()

    def on_refresh_driver(self) -> None:
        h: Optional[wintypes.HANDLE] = None
        try:
            c = self._gather_config_from_ui()
            h, car_addr = self._open_session_and_resolve_car_addr(c)
            final = car_addr + DRIVER_DELTA
            raw = read_process_memory(h, final, 4)
            if len(raw) != 4:
                raise RuntimeError("读取失败")
            self._driver_read.set(str(struct.unpack("<I", raw)[0]))
            self._status.set("读取成功")
            popup_ok()
        except Exception:
            self._driver_read.set("—")
            self._status.set("读取失败")
            popup_fail()
        finally:
            if h:
                kernel32.CloseHandle(h)

    def on_one_click_hide(self) -> None:
        h: Optional[wintypes.HANDLE] = None
        try:
            c = self._gather_config_from_ui()
            h, car_addr = self._open_session_and_resolve_car_addr(c)
            for delta in HIDE_WRITE_DELTAS:
                self._write_u32_at_delta(car_addr, delta, 0, h)
            self._status.set("影藏成功")
            popup_ok()
        except Exception:
            self._status.set("影藏失败")
            popup_fail()
        finally:
            if h:
                kernel32.CloseHandle(h)

    def on_write_driver(self) -> None:
        if not self._driver_write.get().strip():
            self._status.set("请先填写写入值")
            popup_fail()
            return
        h: Optional[wintypes.HANDLE] = None
        try:
            val = parse_write_decimal_u32(self._driver_write.get())
            c = self._gather_config_from_ui()
            h, car_addr = self._open_session_and_resolve_car_addr(c)
            self._write_u32_at_delta(car_addr, DRIVER_DELTA, val, h)
            self._driver_read.set(str(val))
            self._status.set("写入成功")
            popup_ok()
        except Exception:
            self._status.set("写入失败")
            popup_fail()
        finally:
            if h:
                kernel32.CloseHandle(h)

    def run(self) -> None:
        self.root.mainloop()


def main() -> None:
    ensure_admin()
    PointerValueApp().run()


if __name__ == "__main__":
    main()
